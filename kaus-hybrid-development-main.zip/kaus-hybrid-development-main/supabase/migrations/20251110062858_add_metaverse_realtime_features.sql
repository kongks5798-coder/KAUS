/*
  # 메타버스 실시간 기능 추가

  1. 새 테이블 추가
    - `metaverse_sessions`: 사용자의 현재 메타버스 접속 상태
      - `id` (uuid, primary key)
      - `user_id` (uuid, auth.users 참조)
      - `position_x` (float): X 좌표
      - `position_y` (float): Y 좌표
      - `position_z` (float): Z 좌표
      - `character_color` (text): 캐릭터 색상
      - `character_type` (text): 캐릭터 타입
      - `last_active_at` (timestamptz): 마지막 활동 시간
      - `created_at` (timestamptz)
      
    - `metaverse_chat`: 실시간 채팅 메시지
      - `id` (uuid, primary key)
      - `user_id` (uuid, auth.users 참조)
      - `message` (text): 채팅 메시지
      - `created_at` (timestamptz)
      
    - `nft_trades`: NFT 거래 제안 및 기록
      - `id` (uuid, primary key)
      - `nft_id` (text): NFT ID (blockchain_mirror 참조)
      - `seller_id` (uuid): 판매자
      - `buyer_id` (uuid, nullable): 구매자
      - `price` (numeric): 제안 가격
      - `status` (text): pending, accepted, rejected, completed, cancelled
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
      - `completed_at` (timestamptz, nullable)

  2. 보안
    - 모든 테이블에 RLS 활성화
    - 인증된 사용자만 자신의 데이터 읽기/쓰기 가능
    - 채팅은 모든 인증된 사용자가 읽을 수 있음
*/

-- 메타버스 세션 테이블
CREATE TABLE IF NOT EXISTS metaverse_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  position_x real DEFAULT 0,
  position_y real DEFAULT 0,
  position_z real DEFAULT 5,
  character_color text DEFAULT '#8B0000',
  character_type text DEFAULT '관우',
  last_active_at timestamptz DEFAULT now(),
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

ALTER TABLE metaverse_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all active sessions"
  ON metaverse_sessions FOR SELECT
  TO authenticated
  USING (last_active_at > now() - interval '5 minutes');

CREATE POLICY "Users can insert own session"
  ON metaverse_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own session"
  ON metaverse_sessions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own session"
  ON metaverse_sessions FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- 메타버스 채팅 테이블
CREATE TABLE IF NOT EXISTS metaverse_chat (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL CHECK (length(message) > 0 AND length(message) <= 500),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE metaverse_chat ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view recent chat messages"
  ON metaverse_chat FOR SELECT
  TO authenticated
  USING (created_at > now() - interval '1 hour');

CREATE POLICY "Authenticated users can send messages"
  ON metaverse_chat FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- NFT 거래 테이블
CREATE TABLE IF NOT EXISTS nft_trades (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nft_id text NOT NULL,
  seller_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  buyer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  price numeric NOT NULL CHECK (price > 0),
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'rejected', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE nft_trades ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view trades involving them"
  ON nft_trades FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM customers c1
      WHERE c1.id = seller_id AND c1.id = (SELECT id FROM customers WHERE id = auth.uid())
    )
    OR
    EXISTS (
      SELECT 1 FROM customers c2
      WHERE c2.id = buyer_id AND c2.id = (SELECT id FROM customers WHERE id = auth.uid())
    )
    OR
    status = 'pending'
  );

CREATE POLICY "Sellers can create trade offers"
  ON nft_trades FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM customers
      WHERE id = seller_id AND id = auth.uid()
    )
  );

CREATE POLICY "Sellers and buyers can update trades"
  ON nft_trades FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM customers c1
      WHERE c1.id = seller_id AND c1.id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM customers c2
      WHERE c2.id = buyer_id AND c2.id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM customers c1
      WHERE c1.id = seller_id AND c1.id = auth.uid()
    )
    OR
    EXISTS (
      SELECT 1 FROM customers c2
      WHERE c2.id = buyer_id AND c2.id = auth.uid()
    )
  );

-- 인덱스 추가
CREATE INDEX IF NOT EXISTS idx_metaverse_sessions_user_id ON metaverse_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_metaverse_sessions_last_active ON metaverse_sessions(last_active_at);
CREATE INDEX IF NOT EXISTS idx_metaverse_chat_created_at ON metaverse_chat(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_nft_trades_status ON nft_trades(status);
CREATE INDEX IF NOT EXISTS idx_nft_trades_seller ON nft_trades(seller_id);
CREATE INDEX IF NOT EXISTS idx_nft_trades_buyer ON nft_trades(buyer_id);

-- 자동으로 세션 업데이트 함수
CREATE OR REPLACE FUNCTION update_session_activity()
RETURNS TRIGGER AS $$
BEGIN
  NEW.last_active_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 세션 업데이트 트리거
DROP TRIGGER IF EXISTS trigger_update_session_activity ON metaverse_sessions;
CREATE TRIGGER trigger_update_session_activity
  BEFORE UPDATE ON metaverse_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_session_activity();
