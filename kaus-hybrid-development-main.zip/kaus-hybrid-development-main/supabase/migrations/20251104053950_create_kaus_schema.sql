/*
  # K-AUS 데이터베이스 스키마 생성

  ## 개요
  K-AUS (Korean Authentication System) 패션 명품 블록체인 정품 인증 시스템의
  전체 데이터베이스 스키마를 생성합니다.

  ## 생성되는 테이블
  
  ### 1. customers (고객)
  - 고객 기본 정보 저장
  - Supabase Auth와 연동
  - 블록체인 지갑 주소 저장
  
  ### 2. products (상품)
  - 명품 패션 상품 정보
  - 가격, 브랜드, 이미지 등
  - 정품 인증 필요 여부 플래그
  
  ### 3. orders (주문)
  - 고객의 구매 주문 정보
  - 상품 및 고객과 연결
  - 주문 상태 추적
  
  ### 4. blockchain_jobs (블록체인 작업 큐)
  - 백그라운드 처리할 블록체인 작업 목록
  - 지갑 생성, NFT 발급 등
  - 작업 상태 및 재시도 관리
  
  ### 5. blockchain_mirror (블록체인 데이터 미러)
  - 블록체인에 발급된 NFT 정보를 로컬에 복사
  - 빠른 조회를 위한 미러링
  - 트랜잭션 해시, 블록 번호 등 저장

  ## 보안 설정
  - 모든 테이블에 Row Level Security (RLS) 활성화
  - 고객은 자신의 데이터만 조회 가능
  - 상품은 모든 사용자가 조회 가능
*/

-- customers 테이블 생성
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  name text NOT NULL,
  phone text,
  wallet_address text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- products 테이블 생성
CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  brand text NOT NULL,
  price numeric NOT NULL CHECK (price >= 0),
  description text,
  image_url text,
  requires_nft boolean DEFAULT true,
  stock integer DEFAULT 0 CHECK (stock >= 0),
  created_at timestamptz DEFAULT now()
);

-- orders 테이블 생성
CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'cancelled')),
  total_price numeric NOT NULL CHECK (total_price >= 0),
  shipping_address text,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- blockchain_jobs 테이블 생성
CREATE TABLE IF NOT EXISTS blockchain_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_type text NOT NULL CHECK (job_type IN ('CREATE_WALLET', 'MINT_NFT')),
  status text NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'PROCESSING', 'COMPLETED', 'FAILED')),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  order_id uuid REFERENCES orders(id) ON DELETE CASCADE,
  retry_count integer DEFAULT 0 CHECK (retry_count >= 0),
  error_message text,
  result_data jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

-- blockchain_mirror 테이블 생성
CREATE TABLE IF NOT EXISTS blockchain_mirror (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nft_id text NOT NULL UNIQUE,
  transaction_hash text NOT NULL,
  block_number bigint NOT NULL CHECK (block_number >= 0),
  owner_address text NOT NULL,
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
  metadata_uri text,
  minted_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- 인덱스 생성 (성능 최적화)
CREATE INDEX IF NOT EXISTS idx_orders_customer_id ON orders(customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_created_at ON orders(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_status ON blockchain_jobs(status) WHERE status IN ('PENDING', 'PROCESSING');
CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_created_at ON blockchain_jobs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_blockchain_mirror_customer_id ON blockchain_mirror(customer_id);
CREATE INDEX IF NOT EXISTS idx_blockchain_mirror_order_id ON blockchain_mirror(order_id);

-- updated_at 자동 업데이트 트리거 함수
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- customers 테이블 updated_at 트리거
DROP TRIGGER IF EXISTS update_customers_updated_at ON customers;
CREATE TRIGGER update_customers_updated_at
  BEFORE UPDATE ON customers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- blockchain_jobs 테이블 updated_at 트리거
DROP TRIGGER IF EXISTS update_blockchain_jobs_updated_at ON blockchain_jobs;
CREATE TRIGGER update_blockchain_jobs_updated_at
  BEFORE UPDATE ON blockchain_jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Row Level Security 활성화
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE blockchain_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE blockchain_mirror ENABLE ROW LEVEL SECURITY;

-- customers RLS 정책
CREATE POLICY "Users can view own customer data"
  ON customers FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own customer data"
  ON customers FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own customer data"
  ON customers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- products RLS 정책 (모든 사용자가 조회 가능)
CREATE POLICY "Anyone can view products"
  ON products FOR SELECT
  TO authenticated
  USING (true);

-- orders RLS 정책
CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Users can create own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

CREATE POLICY "Users can update own orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid())
  WITH CHECK (customer_id = auth.uid());

-- blockchain_jobs RLS 정책
CREATE POLICY "Users can view own blockchain jobs"
  ON blockchain_jobs FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Users can create own blockchain jobs"
  ON blockchain_jobs FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

-- blockchain_mirror RLS 정책
CREATE POLICY "Users can view own NFTs"
  ON blockchain_mirror FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());
