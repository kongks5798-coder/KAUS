/*
  # Add Metaverse Character Selection

  1. New Tables
    - `metaverse_characters`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `character_type` (text) - Character name like '관우', '장비', '조조', etc.
      - `character_color` (text) - Primary color for character
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `metaverse_characters` table
    - Add policies for users to manage their own character

  3. Notes
    - Each user can have one character
    - Character is selected during signup
    - Can be changed later in profile settings
*/

CREATE TABLE IF NOT EXISTS metaverse_characters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE NOT NULL,
  character_type text NOT NULL DEFAULT '관우',
  character_color text NOT NULL DEFAULT '#8B0000',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE metaverse_characters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own character"
  ON metaverse_characters FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own character"
  ON metaverse_characters FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own character"
  ON metaverse_characters FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own character"
  ON metaverse_characters FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_metaverse_characters_user_id ON metaverse_characters(user_id);
