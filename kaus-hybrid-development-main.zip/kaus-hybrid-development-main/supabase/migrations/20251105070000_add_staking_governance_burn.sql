/*
  # K-AUS V3 기능 확장 - 스테이킹, 거버넌스, 소각

  1. 새 테이블 생성
    - `token_stakes`: 토큰 스테이킹 정보
      - `id` (uuid, primary key)
      - `customer_id` (uuid, foreign key)
      - `amount` (numeric) - 스테이킹 수량
      - `lock_period` (integer) - 락업 기간 (초)
      - `start_time` (timestamptz) - 시작 시간
      - `last_claim_time` (timestamptz) - 마지막 리워드 청구 시간
      - `tx_hash` (text) - 블록체인 트랜잭션 해시
      - `status` (text) - active, unstaked
      - `voting_power` (numeric) - 투표권

    - `governance_proposals`: 거버넌스 제안
      - `id` (uuid, primary key)
      - `proposal_id` (integer) - 블록체인 제안 ID
      - `title` (text) - 제안 제목
      - `description` (text) - 제안 설명
      - `proposer_id` (uuid, foreign key)
      - `votes_for` (numeric) - 찬성 투표
      - `votes_against` (numeric) - 반대 투표
      - `start_time` (timestamptz) - 시작 시간
      - `end_time` (timestamptz) - 종료 시간
      - `executed` (boolean) - 실행 여부
      - `tx_hash` (text) - 블록체인 트랜잭션 해시

    - `governance_votes`: 거버넌스 투표 기록
      - `id` (uuid, primary key)
      - `proposal_id` (uuid, foreign key)
      - `voter_id` (uuid, foreign key)
      - `support` (boolean) - 찬성 여부
      - `voting_power` (numeric) - 행사한 투표권
      - `tx_hash` (text) - 블록체인 트랜잭션 해시
      - `voted_at` (timestamptz) - 투표 시간

    - `token_burns`: 토큰 소각 기록
      - `id` (uuid, primary key)
      - `order_id` (uuid, foreign key, nullable)
      - `amount` (numeric) - 소각 수량
      - `reason` (text) - 소각 이유
      - `tx_hash` (text) - 블록체인 트랜잭션 해시
      - `burned_at` (timestamptz) - 소각 시간

  2. 보안
    - 모든 테이블에 RLS 활성화
    - 인증된 사용자만 본인 데이터 조회 가능
    - 제안은 모두 조회 가능
    - 관리자만 소각 기록 조회 가능

  3. 인덱스
    - 성능 최적화를 위한 인덱스 추가
*/

-- 1. 토큰 스테이킹 테이블
CREATE TABLE IF NOT EXISTS token_stakes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  amount numeric(78, 0) NOT NULL CHECK (amount > 0),
  lock_period integer NOT NULL CHECK (lock_period IN (2592000, 7776000, 15552000, 31536000)),
  start_time timestamptz NOT NULL DEFAULT now(),
  last_claim_time timestamptz NOT NULL DEFAULT now(),
  tx_hash text NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'unstaked')),
  voting_power numeric(78, 0) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 2. 거버넌스 제안 테이블
CREATE TABLE IF NOT EXISTS governance_proposals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id integer NOT NULL UNIQUE,
  title text NOT NULL CHECK (length(title) > 0),
  description text NOT NULL CHECK (length(description) > 0),
  proposer_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  votes_for numeric(78, 0) NOT NULL DEFAULT 0,
  votes_against numeric(78, 0) NOT NULL DEFAULT 0,
  start_time timestamptz NOT NULL DEFAULT now(),
  end_time timestamptz NOT NULL,
  executed boolean NOT NULL DEFAULT false,
  tx_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- 3. 거버넌스 투표 기록 테이블
CREATE TABLE IF NOT EXISTS governance_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  proposal_id uuid NOT NULL REFERENCES governance_proposals(id) ON DELETE CASCADE,
  voter_id uuid NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
  support boolean NOT NULL,
  voting_power numeric(78, 0) NOT NULL CHECK (voting_power > 0),
  tx_hash text NOT NULL,
  voted_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(proposal_id, voter_id)
);

-- 4. 토큰 소각 기록 테이블
CREATE TABLE IF NOT EXISTS token_burns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id) ON DELETE SET NULL,
  amount numeric(78, 0) NOT NULL CHECK (amount > 0),
  reason text NOT NULL,
  tx_hash text NOT NULL,
  burned_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

-- 5. 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_token_stakes_customer_id ON token_stakes(customer_id);
CREATE INDEX IF NOT EXISTS idx_token_stakes_status ON token_stakes(status);
CREATE INDEX IF NOT EXISTS idx_governance_proposals_proposal_id ON governance_proposals(proposal_id);
CREATE INDEX IF NOT EXISTS idx_governance_proposals_end_time ON governance_proposals(end_time);
CREATE INDEX IF NOT EXISTS idx_governance_votes_proposal_id ON governance_votes(proposal_id);
CREATE INDEX IF NOT EXISTS idx_governance_votes_voter_id ON governance_votes(voter_id);
CREATE INDEX IF NOT EXISTS idx_token_burns_order_id ON token_burns(order_id);

-- 6. RLS 정책 설정

-- token_stakes 테이블
ALTER TABLE token_stakes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own stakes"
  ON token_stakes FOR SELECT
  TO authenticated
  USING (customer_id = auth.uid());

CREATE POLICY "Users can insert own stakes"
  ON token_stakes FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = auth.uid());

CREATE POLICY "Users can update own stakes"
  ON token_stakes FOR UPDATE
  TO authenticated
  USING (customer_id = auth.uid())
  WITH CHECK (customer_id = auth.uid());

-- governance_proposals 테이블
ALTER TABLE governance_proposals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view proposals"
  ON governance_proposals FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can create proposals"
  ON governance_proposals FOR INSERT
  TO authenticated
  WITH CHECK (proposer_id = auth.uid());

-- governance_votes 테이블
ALTER TABLE governance_votes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all votes"
  ON governance_votes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own votes"
  ON governance_votes FOR INSERT
  TO authenticated
  WITH CHECK (voter_id = auth.uid());

-- token_burns 테이블
ALTER TABLE token_burns ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Everyone can view burns"
  ON token_burns FOR SELECT
  TO authenticated
  USING (true);

-- 7. 트리거 함수: updated_at 자동 업데이트
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 8. 트리거 생성
DROP TRIGGER IF EXISTS update_token_stakes_updated_at ON token_stakes;
CREATE TRIGGER update_token_stakes_updated_at
  BEFORE UPDATE ON token_stakes
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_governance_proposals_updated_at ON governance_proposals;
CREATE TRIGGER update_governance_proposals_updated_at
  BEFORE UPDATE ON governance_proposals
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
