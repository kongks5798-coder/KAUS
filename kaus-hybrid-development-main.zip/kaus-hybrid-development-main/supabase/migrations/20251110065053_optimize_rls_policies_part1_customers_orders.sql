/*
  # Optimize RLS Policies - Part 1: Customers and Orders

  1. Changes
    - Replace auth.uid() with (SELECT auth.uid()) in RLS policies
    - This prevents re-evaluation of auth functions for each row
    - Significantly improves query performance at scale
    
  2. Tables affected in this migration
    - customers
    - orders
    - blockchain_jobs
    - blockchain_mirror
    - blockchain_pending_txs
*/

-- Customers policies (id references auth.users directly)
DROP POLICY IF EXISTS "Users can view own customer data" ON customers;
DROP POLICY IF EXISTS "Users can insert own customer data" ON customers;
DROP POLICY IF EXISTS "Users can update own customer data" ON customers;

CREATE POLICY "Users can view own customer data"
  ON customers FOR SELECT
  TO authenticated
  USING (id = (SELECT auth.uid()));

CREATE POLICY "Users can insert own customer data"
  ON customers FOR INSERT
  TO authenticated
  WITH CHECK (id = (SELECT auth.uid()));

CREATE POLICY "Users can update own customer data"
  ON customers FOR UPDATE
  TO authenticated
  USING (id = (SELECT auth.uid()))
  WITH CHECK (id = (SELECT auth.uid()));

-- Orders policies
DROP POLICY IF EXISTS "Users can view own orders" ON orders;
DROP POLICY IF EXISTS "Users can create own orders" ON orders;
DROP POLICY IF EXISTS "Users can update own orders" ON orders;

CREATE POLICY "Users can view own orders"
  ON orders FOR SELECT
  TO authenticated
  USING (customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can create own orders"
  ON orders FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own orders"
  ON orders FOR UPDATE
  TO authenticated
  USING (customer_id = (SELECT auth.uid()))
  WITH CHECK (customer_id = (SELECT auth.uid()));

-- Blockchain jobs policies
DROP POLICY IF EXISTS "Users can view own blockchain jobs" ON blockchain_jobs;
DROP POLICY IF EXISTS "Users can create own blockchain jobs" ON blockchain_jobs;

CREATE POLICY "Users can view own blockchain jobs"
  ON blockchain_jobs FOR SELECT
  TO authenticated
  USING (customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can create own blockchain jobs"
  ON blockchain_jobs FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = (SELECT auth.uid()));

-- Blockchain mirror policies
DROP POLICY IF EXISTS "Users can view own NFTs" ON blockchain_mirror;

CREATE POLICY "Users can view own NFTs"
  ON blockchain_mirror FOR SELECT
  TO authenticated
  USING (customer_id = (SELECT auth.uid()));

-- Blockchain pending txs policies
DROP POLICY IF EXISTS "Users can view own pending transactions" ON blockchain_pending_txs;

CREATE POLICY "Users can view own pending transactions"
  ON blockchain_pending_txs FOR SELECT
  TO authenticated
  USING (job_id IN (
    SELECT id FROM blockchain_jobs WHERE customer_id = (SELECT auth.uid())
  ));
