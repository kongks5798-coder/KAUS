/*
  # Add Blockchain Transaction Atomicity Support

  1. New Tables
    - `blockchain_pending_txs`
      - Tracks submitted transactions waiting for confirmation
      - Links to blockchain_jobs for recovery
  
  2. Changes
    - Add `next_retry_at` to blockchain_jobs for exponential backoff
    - Add `worker_id` and `locked_at` for distributed lock
    - Add `chain` field for multi-chain support
  
  3. New Functions
    - `complete_nft_mint_transaction()` - Atomic completion of NFT minting
    - `acquire_job_lock()` - Distributed job locking mechanism
  
  4. Security
    - RLS enabled on all new tables
    - Only authenticated users can query their own data
*/

-- Add columns to blockchain_jobs
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_jobs' AND column_name = 'next_retry_at'
  ) THEN
    ALTER TABLE blockchain_jobs ADD COLUMN next_retry_at TIMESTAMPTZ;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_jobs' AND column_name = 'worker_id'
  ) THEN
    ALTER TABLE blockchain_jobs ADD COLUMN worker_id TEXT;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_jobs' AND column_name = 'locked_at'
  ) THEN
    ALTER TABLE blockchain_jobs ADD COLUMN locked_at TIMESTAMPTZ;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_jobs' AND column_name = 'chain'
  ) THEN
    ALTER TABLE blockchain_jobs ADD COLUMN chain TEXT DEFAULT 'base';
  END IF;
END $$;

-- Add chain to blockchain_mirror
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_mirror' AND column_name = 'chain'
  ) THEN
    ALTER TABLE blockchain_mirror ADD COLUMN chain TEXT DEFAULT 'base';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'blockchain_mirror' AND column_name = 'chain_id'
  ) THEN
    ALTER TABLE blockchain_mirror ADD COLUMN chain_id INTEGER DEFAULT 84532;
  END IF;
END $$;

-- Create pending transactions table
CREATE TABLE IF NOT EXISTS blockchain_pending_txs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id UUID REFERENCES blockchain_jobs(id) ON DELETE CASCADE,
  tx_hash TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'pending',
  submitted_at TIMESTAMPTZ DEFAULT NOW(),
  confirmed_at TIMESTAMPTZ,
  confirmations INTEGER DEFAULT 0,
  block_number INTEGER,
  error_message TEXT,
  CHECK (status IN ('pending', 'confirmed', 'failed'))
);

ALTER TABLE blockchain_pending_txs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own pending transactions"
  ON blockchain_pending_txs FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM blockchain_jobs
      WHERE blockchain_jobs.id = blockchain_pending_txs.job_id
      AND blockchain_jobs.customer_id = auth.uid()
    )
  );

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_next_retry 
  ON blockchain_jobs(next_retry_at) WHERE status = 'PENDING';

CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_worker 
  ON blockchain_jobs(worker_id, locked_at);

CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_chain 
  ON blockchain_jobs(chain);

CREATE INDEX IF NOT EXISTS idx_pending_txs_status 
  ON blockchain_pending_txs(status, submitted_at);

CREATE INDEX IF NOT EXISTS idx_pending_txs_job 
  ON blockchain_pending_txs(job_id);

-- Atomic NFT mint completion function
CREATE OR REPLACE FUNCTION complete_nft_mint_transaction(
  p_job_id UUID,
  p_nft_id TEXT,
  p_tx_hash TEXT,
  p_block_number INTEGER,
  p_owner_address TEXT,
  p_customer_id UUID,
  p_order_id UUID,
  p_product_id UUID,
  p_chain TEXT DEFAULT 'base',
  p_chain_id INTEGER DEFAULT 84532
) RETURNS VOID AS $$
BEGIN
  -- Insert into blockchain_mirror
  INSERT INTO blockchain_mirror (
    nft_id,
    transaction_hash,
    block_number,
    owner_address,
    customer_id,
    order_id,
    product_id,
    chain,
    chain_id,
    minted_at
  ) VALUES (
    p_nft_id,
    p_tx_hash,
    p_block_number,
    p_owner_address,
    p_customer_id,
    p_order_id,
    p_product_id,
    p_chain,
    p_chain_id,
    NOW()
  );

  -- Update order status
  UPDATE orders 
  SET 
    status = 'completed',
    completed_at = NOW()
  WHERE id = p_order_id;

  -- Update job status
  UPDATE blockchain_jobs
  SET
    status = 'COMPLETED',
    completed_at = NOW(),
    result_data = jsonb_build_object(
      'nft_id', p_nft_id,
      'transaction_hash', p_tx_hash,
      'block_number', p_block_number
    )
  WHERE id = p_job_id;

  -- Update pending tx status if exists
  UPDATE blockchain_pending_txs
  SET
    status = 'confirmed',
    confirmed_at = NOW(),
    block_number = p_block_number
  WHERE tx_hash = p_tx_hash;

EXCEPTION
  WHEN OTHERS THEN
    RAISE EXCEPTION 'Transaction failed: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Job lock acquisition function
CREATE OR REPLACE FUNCTION acquire_job_lock(
  p_job_id UUID,
  p_worker_id TEXT
) RETURNS BOOLEAN AS $$
DECLARE
  rows_updated INTEGER;
BEGIN
  UPDATE blockchain_jobs
  SET
    status = 'PROCESSING',
    worker_id = p_worker_id,
    locked_at = NOW()
  WHERE
    id = p_job_id
    AND status = 'PENDING'
    AND (next_retry_at IS NULL OR next_retry_at <= NOW());
  
  GET DIAGNOSTICS rows_updated = ROW_COUNT;
  RETURN rows_updated > 0;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Release stale locks (locks held for more than 5 minutes)
CREATE OR REPLACE FUNCTION release_stale_job_locks() RETURNS INTEGER AS $$
DECLARE
  released_count INTEGER;
BEGIN
  UPDATE blockchain_jobs
  SET
    status = 'PENDING',
    worker_id = NULL,
    locked_at = NULL,
    next_retry_at = NOW() + INTERVAL '1 minute'
  WHERE
    status = 'PROCESSING'
    AND locked_at < NOW() - INTERVAL '5 minutes';
  
  GET DIAGNOSTICS released_count = ROW_COUNT;
  RETURN released_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
