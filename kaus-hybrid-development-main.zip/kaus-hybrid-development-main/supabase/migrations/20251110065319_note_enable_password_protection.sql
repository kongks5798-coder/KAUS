/*
  # Enable Leaked Password Protection - Configuration Note

  1. Important Security Setting
    - Supabase Auth can check passwords against HaveIBeenPwned.org database
    - This prevents users from using compromised passwords
    
  2. How to Enable
    This setting CANNOT be enabled via SQL migrations.
    It must be configured through the Supabase Dashboard:
    
    Steps:
    a) Go to Supabase Dashboard
    b) Navigate to: Authentication > Policies
    c) Find "Password Policy" section
    d) Enable "Check for breached passwords"
    e) This will validate passwords against HaveIBeenPwned during signup/password changes
    
  3. Alternative: Project Configuration
    If using Supabase CLI:
    - Update supabase/config.toml
    - Add under [auth]:
      enable_password_breach_detection = true
    - Run: supabase db push
    
  Note: This migration serves as documentation only.
  The actual setting must be enabled through the dashboard or config file.
*/

-- This is a documentation-only migration
-- No SQL changes required
SELECT 1;
