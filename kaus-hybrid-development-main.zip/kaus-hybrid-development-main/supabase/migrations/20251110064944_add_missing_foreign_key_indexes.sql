/*
  # Add Missing Foreign Key Indexes

  1. Performance Improvements
    - Add indexes for all foreign key columns to improve query performance
    - These indexes are critical for JOIN operations and foreign key constraint checks
    
  2. Tables affected
    - blockchain_jobs (customer_id, order_id)
    - blockchain_mirror (product_id)
    - governance_proposals (proposer_id)
    - metaverse_chat (user_id)
    - nft_transfer_requests (from_customer_id)
    - orders (product_id)
*/

-- Add index for blockchain_jobs.customer_id
CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_customer_id 
ON blockchain_jobs(customer_id);

-- Add index for blockchain_jobs.order_id
CREATE INDEX IF NOT EXISTS idx_blockchain_jobs_order_id 
ON blockchain_jobs(order_id);

-- Add index for blockchain_mirror.product_id
CREATE INDEX IF NOT EXISTS idx_blockchain_mirror_product_id 
ON blockchain_mirror(product_id);

-- Add index for governance_proposals.proposer_id
CREATE INDEX IF NOT EXISTS idx_governance_proposals_proposer_id 
ON governance_proposals(proposer_id);

-- Add index for metaverse_chat.user_id
CREATE INDEX IF NOT EXISTS idx_metaverse_chat_user_id 
ON metaverse_chat(user_id);

-- Add index for nft_transfer_requests.from_customer_id
CREATE INDEX IF NOT EXISTS idx_nft_transfer_requests_from_customer_id 
ON nft_transfer_requests(from_customer_id);

-- Add index for orders.product_id
CREATE INDEX IF NOT EXISTS idx_orders_product_id 
ON orders(product_id);
