/*
  # Add Storage Buckets for NFT Media

  1. Storage Buckets
    - `nft-metadata` - For JSON metadata files
    - `nft-images` - For product images

  2. Security
    - Public read access for both buckets
    - Authenticated users can upload to both buckets
*/

INSERT INTO storage.buckets (id, name, public)
VALUES
  ('nft-metadata', 'nft-metadata', true),
  ('nft-images', 'nft-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public can view metadata"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'nft-metadata');

CREATE POLICY "Authenticated users can upload metadata"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'nft-metadata');

CREATE POLICY "Public can view images"
  ON storage.objects FOR SELECT
  TO public
  USING (bucket_id = 'nft-images');

CREATE POLICY "Authenticated users can upload images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'nft-images');
