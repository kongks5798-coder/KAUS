/*
  # Optimize RLS Policies - Part 2: Remaining Tables

  1. Changes
    - Replace auth.uid() with (SELECT auth.uid()) in RLS policies
    - Improves query performance at scale
    
  2. Tables affected in this migration
    - nft_transfer_requests (from_customer_id, to_email)
    - token_stakes (customer_id)
    - governance_proposals (proposer_id)
    - governance_votes (voter_id)
    - notifications (user_id)
    - metaverse_characters (user_id)
    - metaverse_chat (user_id)
    - metaverse_sessions (user_id)
    - nft_trades (seller_id, buyer_id)
*/

-- NFT transfer requests policies
DROP POLICY IF EXISTS "Users can create transfer requests for their NFTs" ON nft_transfer_requests;
DROP POLICY IF EXISTS "Users can view their own transfer requests" ON nft_transfer_requests;

CREATE POLICY "Users can create transfer requests for their NFTs"
  ON nft_transfer_requests FOR INSERT
  TO authenticated
  WITH CHECK (from_customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can view their own transfer requests"
  ON nft_transfer_requests FOR SELECT
  TO authenticated
  USING (from_customer_id = (SELECT auth.uid()));

-- Token stakes policies
DROP POLICY IF EXISTS "Users can view own stakes" ON token_stakes;
DROP POLICY IF EXISTS "Users can insert own stakes" ON token_stakes;
DROP POLICY IF EXISTS "Users can update own stakes" ON token_stakes;

CREATE POLICY "Users can view own stakes"
  ON token_stakes FOR SELECT
  TO authenticated
  USING (customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can insert own stakes"
  ON token_stakes FOR INSERT
  TO authenticated
  WITH CHECK (customer_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own stakes"
  ON token_stakes FOR UPDATE
  TO authenticated
  USING (customer_id = (SELECT auth.uid()))
  WITH CHECK (customer_id = (SELECT auth.uid()));

-- Governance proposals policies
DROP POLICY IF EXISTS "Users can create proposals" ON governance_proposals;

CREATE POLICY "Users can create proposals"
  ON governance_proposals FOR INSERT
  TO authenticated
  WITH CHECK (proposer_id = (SELECT auth.uid()));

-- Governance votes policies
DROP POLICY IF EXISTS "Users can insert own votes" ON governance_votes;

CREATE POLICY "Users can insert own votes"
  ON governance_votes FOR INSERT
  TO authenticated
  WITH CHECK (voter_id = (SELECT auth.uid()));

-- Notifications policies
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

-- Metaverse characters policies
DROP POLICY IF EXISTS "Users can view own character" ON metaverse_characters;
DROP POLICY IF EXISTS "Users can insert own character" ON metaverse_characters;
DROP POLICY IF EXISTS "Users can update own character" ON metaverse_characters;
DROP POLICY IF EXISTS "Users can delete own character" ON metaverse_characters;

CREATE POLICY "Users can view own character"
  ON metaverse_characters FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can insert own character"
  ON metaverse_characters FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own character"
  ON metaverse_characters FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can delete own character"
  ON metaverse_characters FOR DELETE
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- Metaverse chat policies
DROP POLICY IF EXISTS "Authenticated users can send messages" ON metaverse_chat;

CREATE POLICY "Authenticated users can send messages"
  ON metaverse_chat FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

-- Metaverse sessions policies
DROP POLICY IF EXISTS "Users can insert own session" ON metaverse_sessions;
DROP POLICY IF EXISTS "Users can update own session" ON metaverse_sessions;
DROP POLICY IF EXISTS "Users can delete own session" ON metaverse_sessions;

CREATE POLICY "Users can insert own session"
  ON metaverse_sessions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can update own session"
  ON metaverse_sessions FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));

CREATE POLICY "Users can delete own session"
  ON metaverse_sessions FOR DELETE
  TO authenticated
  USING (user_id = (SELECT auth.uid()));

-- NFT trades policies (uses seller_id and buyer_id, not seller_customer_id)
DROP POLICY IF EXISTS "Sellers can create trade offers" ON nft_trades;
DROP POLICY IF EXISTS "Users can view trades involving them" ON nft_trades;
DROP POLICY IF EXISTS "Sellers and buyers can update trades" ON nft_trades;

CREATE POLICY "Sellers can create trade offers"
  ON nft_trades FOR INSERT
  TO authenticated
  WITH CHECK (seller_id = (SELECT auth.uid()));

CREATE POLICY "Users can view trades involving them"
  ON nft_trades FOR SELECT
  TO authenticated
  USING (
    seller_id = (SELECT auth.uid())
    OR buyer_id = (SELECT auth.uid())
  );

CREATE POLICY "Sellers and buyers can update trades"
  ON nft_trades FOR UPDATE
  TO authenticated
  USING (
    seller_id = (SELECT auth.uid())
    OR buyer_id = (SELECT auth.uid())
  )
  WITH CHECK (
    seller_id = (SELECT auth.uid())
    OR buyer_id = (SELECT auth.uid())
  );
