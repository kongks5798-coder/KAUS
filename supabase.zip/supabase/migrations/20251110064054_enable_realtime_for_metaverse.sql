/*
  # 메타버스 테이블 Realtime 활성화

  1. 변경사항
    - metaverse_chat 테이블 Realtime 복제 활성화
    - metaverse_sessions 테이블 Realtime 복제 활성화
    
  2. 이유
    - 실시간 채팅 기능 작동을 위해 필요
    - 멀티플레이어 위치 동기화를 위해 필요
*/

-- Enable realtime for metaverse tables
ALTER PUBLICATION supabase_realtime ADD TABLE metaverse_chat;
ALTER PUBLICATION supabase_realtime ADD TABLE metaverse_sessions;
