/*
  # 메타버스 채팅 테이블 사용자 정보 추가

  1. 변경사항
    - `metaverse_chat` 테이블에 `user_name`, `user_email` 컬럼 추가
    - 외래 키 관계 대신 직접 사용자 정보를 저장
    
  2. 이유
    - Supabase의 auth.users와의 외래 키 관계 문제 해결
    - 실시간 채팅에서 빠른 사용자 정보 조회
*/

-- 사용자 이름과 이메일 컬럼 추가
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'metaverse_chat' AND column_name = 'user_name'
  ) THEN
    ALTER TABLE metaverse_chat ADD COLUMN user_name text DEFAULT 'User';
  END IF;
END $$;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'metaverse_chat' AND column_name = 'user_email'
  ) THEN
    ALTER TABLE metaverse_chat ADD COLUMN user_email text DEFAULT 'unknown@example.com';
  END IF;
END $$;
