/*
  # Fix Function Search Path Mutability

  1. Security Issue
    - Functions without explicit search_path are vulnerable to search path injection attacks
    - Setting search_path to a fixed value prevents this security issue
    
  2. Functions affected
    - update_updated_at_column
    - complete_nft_mint_transaction
    - acquire_job_lock
    - release_stale_job_locks
    - increment_proposal_votes
    - update_session_activity
    
  3. Solution
    - Set search_path = '' for security
    - Use fully qualified names (schema.table) in function bodies
*/

-- Fix update_updated_at_column function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Fix complete_nft_mint_transaction function
CREATE OR REPLACE FUNCTION complete_nft_mint_transaction(
  p_job_id uuid,
  p_nft_id text,
  p_tx_hash text,
  p_block_number bigint,
  p_owner_address text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_customer_id uuid;
  v_order_id uuid;
  v_product_id uuid;
BEGIN
  SELECT customer_id, order_id INTO v_customer_id, v_order_id
  FROM public.blockchain_jobs
  WHERE id = p_job_id;

  SELECT product_id INTO v_product_id
  FROM public.orders
  WHERE id = v_order_id;

  INSERT INTO public.blockchain_mirror (
    nft_id,
    transaction_hash,
    block_number,
    owner_address,
    customer_id,
    order_id,
    product_id,
    created_at
  ) VALUES (
    p_nft_id,
    p_tx_hash,
    p_block_number,
    p_owner_address,
    v_customer_id,
    v_order_id,
    v_product_id,
    now()
  );

  UPDATE public.blockchain_jobs
  SET 
    status = 'COMPLETED',
    completed_at = now(),
    result_data = jsonb_build_object(
      'nft_id', p_nft_id,
      'transaction_hash', p_tx_hash,
      'block_number', p_block_number
    )
  WHERE id = p_job_id;

  UPDATE public.orders
  SET 
    status = 'completed',
    completed_at = now()
  WHERE id = v_order_id;
END;
$$;

-- Fix acquire_job_lock function
CREATE OR REPLACE FUNCTION acquire_job_lock(
  p_job_id uuid,
  p_worker_id text,
  p_lock_timeout interval DEFAULT '5 minutes'
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_locked boolean;
BEGIN
  UPDATE public.blockchain_jobs
  SET
    status = 'PROCESSING',
    updated_at = now()
  WHERE id = p_job_id
    AND status = 'PENDING'
    AND (
      updated_at IS NULL
      OR updated_at < (now() - p_lock_timeout)
    );

  GET DIAGNOSTICS v_locked = ROW_COUNT;
  RETURN v_locked > 0;
END;
$$;

-- Fix release_stale_job_locks function
CREATE OR REPLACE FUNCTION release_stale_job_locks(
  p_timeout interval DEFAULT '10 minutes'
)
RETURNS integer
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  v_count integer;
BEGIN
  UPDATE public.blockchain_jobs
  SET
    status = 'PENDING',
    updated_at = now()
  WHERE status = 'PROCESSING'
    AND updated_at < (now() - p_timeout);

  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$;

-- Fix increment_proposal_votes function
CREATE OR REPLACE FUNCTION increment_proposal_votes(
  p_proposal_id uuid,
  p_support boolean,
  p_voting_power numeric
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  IF p_support THEN
    UPDATE public.governance_proposals
    SET votes_for = votes_for + p_voting_power
    WHERE id = p_proposal_id;
  ELSE
    UPDATE public.governance_proposals
    SET votes_against = votes_against + p_voting_power
    WHERE id = p_proposal_id;
  END IF;
END;
$$;

-- Fix update_session_activity function
CREATE OR REPLACE FUNCTION update_session_activity()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  NEW.last_active_at = now();
  RETURN NEW;
END;
$$;
